const themeUtil = require('../../utils/theme')
const session = require('../../utils/session')
const api = require('../../utils/api')
const list = require('../../utils/list')
const format = require('../../utils/format')
const ui = require('../../utils/ui')
const bridge = require('../../utils/bridge')
const navigation = require('../../utils/navigation')

const PAGE_SIZE = 20

function progressOf(deposit, total) {
  const amount = Number(deposit || 0) + Number(total || 0)
  return amount > 0 ? Math.max(0, Math.min(100, Math.round(Number(deposit || 0) * 100 / amount))) : 0
}

function decorateCustom(item) {
  const remain = Number(item.remainAmount || 0)
  return Object.assign({}, item, {
    arrived: Number(item.arrivalStatus) === 1,
    customerText: item.customerName || item.memberName || '未记客户',
    goodsText: item.goodsName || item.styleItemName || '定制货品',
    depositText: format.money(item.depositAmount),
    remainText: format.money(remain),
    progress: progressOf(item.depositAmount, remain),
    pickupText: item.pickupDate ? format.dateText(item.pickupDate) : '未约定',
    statusText: Number(item.arrivalStatus) === 1 ? '已到店待取' : '工坊匠造中'
  })
}

Page({
  data: {
    theme: {},
    filter: 'all',
    keyword: '',
    allRows: [],
    rows: [],
    pageNum: 1,
    hasMore: false,
    loadingMore: false,
    loading: false,
    error: '',
    arrivingId: 0,
    totalText: '0'
  },
  onShow() {
    themeUtil.apply(this)
    if (session.requireLogin()) this.load()
  },
  async onPullDownRefresh() {
    await this.load()
    wx.stopPullDownRefresh()
  },
  onReachBottom() {
    if (this.data.hasMore && !this.data.loading && !this.data.loadingMore) {
      this.loadMore()
    }
  },
  scrollTop() { wx.pageScrollTo({ scrollTop: 0, duration: 260 }) },
  onKeyword(e) { this.setData({ keyword: e.detail.value }) },
  setFilter(e) {
    const filter = e.currentTarget.dataset.filter
    this.setData({ filter, rows: this.filterRows(this.data.allRows, filter) })
  },
  filterRows(rows, filter) {
    if (filter === 'waiting') return rows.filter((item) => Number(item.arrivalStatus) !== 1)
    if (filter === 'arrived') return rows.filter((item) => Number(item.arrivalStatus) === 1)
    return rows
  },
  async load() {
    this.setData({ loading: true, error: '', pageNum: 1 })
    try {
      const data = await api.customList({ pageNum: 1, pageSize: PAGE_SIZE, keyword: this.data.keyword })
      const allRows = list.rows(data).map(decorateCustom)
      const total = list.total(data) || allRows.length
      this.setData({
        allRows,
        rows: this.filterRows(allRows, this.data.filter),
        pageNum: 1,
        totalText: String(total),
        hasMore: allRows.length < total && allRows.length >= PAGE_SIZE
      })
    } catch (error) {
      this.setData({ error: error.message || '加载失败' })
    } finally {
      this.setData({ loading: false })
    }
  },
  async loadMore() {
    if (this.data.loadingMore || !this.data.hasMore) return
    const nextPage = this.data.pageNum + 1
    this.setData({ loadingMore: true })
    try {
      const data = await api.customList({ pageNum: nextPage, pageSize: PAGE_SIZE, keyword: this.data.keyword })
      const nextRows = list.rows(data).map(decorateCustom)
      const allRows = this.data.allRows.concat(nextRows)
      const total = list.total(data) || allRows.length
      this.setData({
        allRows,
        rows: this.filterRows(allRows, this.data.filter),
        pageNum: nextPage,
        totalText: String(total),
        hasMore: nextRows.length >= PAGE_SIZE && allRows.length < total
      })
    } catch (error) { ui.toast(error.message || '加载更多失败') }
    finally { this.setData({ loadingMore: false }) }
  },
  async arrive(e) {
    const id = e.currentTarget.dataset.id
    if (this.data.arrivingId) return
    try { await ui.confirm('确认定制到货', '确认后客户可到店取货，并进入待结尾款流程。', '确认到货') } catch (error) { return }
    this.setData({ arrivingId: id })
    try {
      await api.customArrive(id, { remark: '门店确认到货' })
      ui.toast('已标记到店', 'success')
      await this.load()
    } catch (error) { ui.toast(error.message || '到货确认失败') }
    finally { this.setData({ arrivingId: 0 }) }
  },
  payRemain(e) {
    const row = this.data.allRows.find((item) => String(item.id) === String(e.currentTarget.dataset.id))
    if (!row) return
    bridge.putCustom(row)
    navigation.open('/pages/sale/sale')
    ui.toast('已带入定制客户：' + (row.customerText || '定制客户'))
  },
  onTheme() { themeUtil.apply(this) }
})
